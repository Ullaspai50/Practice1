#ifndef APP_H
#define APP_H


#define _1SEC_COUNT 	244
#define _500MSEC_COUNT 122
#define _250MSEC_COUNT 122 //61

#define LNG_PRESS_DLY	3
#define LNG_PRESS_UNIT	5

#define MODE_POWER_ON 0
#define MODE_HEATING  1
#define MODE_READY  2
#define MODE_LOW_VLT 3

#endif